# 2ms Study Platform

A comprehensive study platform powered by AI assistance and smart document management, designed to enhance the learning experience for students.

## 🚀 Features

### 🤖 AI Assistant "Antony"
- Interactive chat interface with intelligent study assistance
- Conversation history and context retention
- Specialized study-focused responses
- 24/7 availability for learning support

### 📄 PDF Document Manager
- Drag-and-drop file uploads
- Document organization and search
- Built-in PDF viewer
- File size tracking and statistics
- Download and sharing capabilities

### 🏠 Clean, Modern Interface
- Responsive design for all devices
- Orange and white themed UI
- Smooth transitions and animations
- Intuitive navigation system

### 👥 Credits System
- Team information and contributions
- Technology stack overview
- Project information and statistics

## 🛠️ Technology Stack

- **Frontend**: React 18, TypeScript, Tailwind CSS
- **Backend**: Node.js with SQLite database
- **Build Tool**: Vite
- **Icons**: Lucide React
- **Database**: Better SQLite3
- **PDF Handling**: React PDF

## 📁 Project Structure

```
src/
├── components/          # Reusable UI components
│   └── Navigation.tsx   # Main navigation component
├── context/            # React context providers
│   └── AppContext.tsx  # Application state management
├── database/           # Database management
│   └── db.ts          # SQLite database operations
├── pages/             # Main application pages
│   ├── HomePage.tsx   # Landing page
│   ├── AIAssistantPage.tsx # AI chat interface
│   ├── PDFPage.tsx    # Document management
│   └── CreditsPage.tsx # Team information
├── services/          # Business logic services
│   └── aiService.ts   # AI response generation
├── types/             # TypeScript type definitions
│   └── index.ts       # Shared interfaces
└── App.tsx           # Main application component
```

## 🚀 Getting Started

### Prerequisites
- Node.js (v18 or higher)
- npm or yarn package manager

### Installation

1. Clone the repository:
   ```bash
   git clone <repository-url>
   cd 2ms-study-platform
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the development server:
   ```bash
   npm run dev
   ```

4. Open your browser and navigate to `http://localhost:5173`

### Building for Production

```bash
npm run build
```

The built files will be available in the `dist/` directory.

## 🗄️ Database Schema

The application uses SQLite with the following tables:

### user_sessions
- `id` (TEXT, PRIMARY KEY)
- `created_at` (DATETIME)
- `last_active` (DATETIME)

### chat_messages
- `id` (TEXT, PRIMARY KEY)
- `session_id` (TEXT, FOREIGN KEY)
- `content` (TEXT)
- `sender` (TEXT)
- `timestamp` (DATETIME)

### pdf_documents
- `id` (TEXT, PRIMARY KEY)
- `session_id` (TEXT, FOREIGN KEY)
- `name` (TEXT)
- `size` (INTEGER)
- `upload_date` (DATETIME)
- `url` (TEXT)

## 🔧 Configuration

### Environment Variables

Create a `.env` file in the root directory:

```env
# AI Configuration (for production integration)
OPENAI_API_KEY=your_openai_api_key_here

# Database Configuration
DATABASE_PATH=./2ms.db
```

## 🧪 Testing

Run the linter:
```bash
npm run lint
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature-name`
3. Make your changes and commit: `git commit -m "Add feature"`
4. Push to the branch: `git push origin feature-name`
5. Submit a pull request

## 👨‍💻 Team

### Mufrih
- **Role**: Lead Developer & AI Integration Specialist
- **Contributions**: AI Assistant Integration, Backend Architecture, Database Design, API Development
- **Skills**: React, Node.js, AI/ML, TypeScript, Database Design

### Masilamani
- **Role**: Frontend Developer & UX Designer
- **Contributions**: User Interface Design, PDF Management System, Responsive Layout, User Experience
- **Skills**: React, UI/UX Design, CSS/Tailwind, JavaScript, Responsive Design

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🙏 Acknowledgments

- Built with love for students everywhere
- Powered by modern web technologies
- Designed with user experience as the top priority

## 📞 Support

For support, feature requests, or bug reports, please open an issue on the GitHub repository.

---

**2ms Study Platform** - Making learning smarter, one student at a time. ❤️