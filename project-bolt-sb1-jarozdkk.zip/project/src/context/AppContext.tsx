import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { ChatMessage, PDFDocument, UserSession } from '../types';
import dbManager from '../database/db';

interface AppContextType {
  currentSession: UserSession | null;
  chatMessages: ChatMessage[];
  pdfDocuments: PDFDocument[];
  addChatMessage: (message: Omit<ChatMessage, 'id'>) => ChatMessage;
  addPDFDocument: (document: Omit<PDFDocument, 'id'>) => PDFDocument;
  removePDFDocument: (documentId: string) => void;
  clearChatHistory: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
};

interface AppProviderProps {
  children: ReactNode;
}

export const AppProvider: React.FC<AppProviderProps> = ({ children }) => {
  const [currentSession, setCurrentSession] = useState<UserSession | null>(null);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [pdfDocuments, setPdfDocuments] = useState<PDFDocument[]>([]);

  useEffect(() => {
    // Initialize session on app start
    const session = dbManager.createSession();
    setCurrentSession(session);

    // Load existing data for the session
    const messages = dbManager.getChatHistory(session.id);
    const documents = dbManager.getPDFDocuments(session.id);
    
    setChatMessages(messages);
    setPdfDocuments(documents);
  }, []);

  const addChatMessage = (messageData: Omit<ChatMessage, 'id'>): ChatMessage => {
    if (!currentSession) throw new Error('No active session');
    
    const message = dbManager.saveChatMessage(currentSession.id, messageData);
    setChatMessages(prev => [...prev, message]);
    dbManager.updateSessionActivity(currentSession.id);
    
    return message;
  };

  const addPDFDocument = (documentData: Omit<PDFDocument, 'id'>): PDFDocument => {
    if (!currentSession) throw new Error('No active session');
    
    const document = dbManager.savePDFDocument(currentSession.id, documentData);
    setPdfDocuments(prev => [document, ...prev]);
    dbManager.updateSessionActivity(currentSession.id);
    
    return document;
  };

  const removePDFDocument = (documentId: string): void => {
    dbManager.deletePDFDocument(documentId);
    setPdfDocuments(prev => prev.filter(doc => doc.id !== documentId));
    
    if (currentSession) {
      dbManager.updateSessionActivity(currentSession.id);
    }
  };

  const clearChatHistory = (): void => {
    setChatMessages([]);
  };

  return (
    <AppContext.Provider value={{
      currentSession,
      chatMessages,
      pdfDocuments,
      addChatMessage,
      addPDFDocument,
      removePDFDocument,
      clearChatHistory,
    }}>
      {children}
    </AppContext.Provider>
  );
};