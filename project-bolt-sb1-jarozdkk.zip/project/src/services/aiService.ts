import { ChatMessage } from '../types';

class AIService {
  // Mock AI responses - in production, this would integrate with OpenAI API
  private responses = [
    "I'm Antony, your AI study assistant! How can I help you with your studies today?",
    "That's a great question! Let me help you understand this concept better.",
    "Based on your study materials, I'd recommend focusing on the key concepts first.",
    "Would you like me to explain this topic in more detail?",
    "I can help you create study notes or practice questions for this subject.",
    "Let's break this down into smaller, manageable parts for better understanding.",
    "Have you tried connecting this concept to real-world examples?",
    "I suggest reviewing the fundamentals before moving to advanced topics.",
  ];

  async generateResponse(userMessage: string, chatHistory: ChatMessage[]): Promise<string> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));

    // Simple keyword-based responses for demo
    const message = userMessage.toLowerCase();
    
    if (message.includes('hello') || message.includes('hi')) {
      return "Hello! I'm Antony, your AI study assistant. I'm here to help you with your studies. What subject are you working on today?";
    }
    
    if (message.includes('math') || message.includes('mathematics')) {
      return "Mathematics is fascinating! Whether it's algebra, calculus, or statistics, I can help you break down complex problems into manageable steps. What specific math topic would you like to explore?";
    }
    
    if (message.includes('science') || message.includes('physics') || message.includes('chemistry')) {
      return "Science is all about understanding how our world works! I can help explain concepts, formulas, and real-world applications. What scientific concept are you curious about?";
    }
    
    if (message.includes('help') || message.includes('study')) {
      return "I'm here to make your studying more effective! I can help you understand concepts, create study plans, generate practice questions, or explain difficult topics. What would you like assistance with?";
    }
    
    if (message.includes('pdf') || message.includes('document')) {
      return "Great! You can upload your study materials in the PDF section. I can help you understand the content, create summaries, or answer questions about your documents.";
    }

    // Return a random helpful response
    const randomIndex = Math.floor(Math.random() * this.responses.length);
    return this.responses[randomIndex];
  }
}

export default new AIService();