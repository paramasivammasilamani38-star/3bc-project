import React from 'react';
import { BookOpen, Brain, FileUp, Zap, Library } from 'lucide-react';

interface HomePageProps {
  onNavigate: (tab: string) => void;
}

const HomePage: React.FC<HomePageProps> = ({ onNavigate }) => {
  const features = [
    {
      icon: Brain,
      title: 'AI Assistant "Antony"',
      description: 'Get instant help with your studies from our intelligent AI assistant.',
      action: () => onNavigate('ai'),
      bgColor: 'bg-orange-50',
      iconColor: 'text-orange-500',
    },
    {
      icon: FileUp,
      title: 'PDF Management',
      description: 'Upload, organize, and manage your study documents seamlessly.',
      action: () => onNavigate('pdf'),
      bgColor: 'bg-blue-50',
      iconColor: 'text-blue-500',
    },
    {
      icon: Library,
      title: 'Study Materials',
      description: 'Access high-quality PDF study materials across various subjects.',
      action: () => onNavigate('materials'),
      bgColor: 'bg-green-50',
      iconColor: 'text-green-500',
    },
    {
      icon: BookOpen,
      title: 'PDF Manager',
      description: 'Upload, organize, and manage your personal study documents.',
      action: () => onNavigate('pdf'),
      bgColor: 'bg-purple-50',
      iconColor: 'text-purple-500',
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-white">
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-4">
              Welcome to <span className="text-orange-500">2ms</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Your comprehensive study platform powered by AI assistance and smart document management
            </p>
            <div className="space-x-4">
              <button
                onClick={() => onNavigate('ai')}
                className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-3 rounded-lg font-semibold text-lg transition-all duration-200 transform hover:scale-105 shadow-lg"
              >
                Start Studying
              </button>
              <button
                onClick={() => onNavigate('materials')}
                className="bg-white hover:bg-gray-50 text-orange-500 border-2 border-orange-500 px-8 py-3 rounded-lg font-semibold text-lg transition-all duration-200 transform hover:scale-105"
              >
                Browse Materials
              </button>
            </div>
          </div>
        </div>

        {/* Decorative elements */}
        <div className="absolute top-0 right-0 -mt-12 -mr-12 w-48 h-48 bg-orange-100 rounded-full opacity-30"></div>
        <div className="absolute bottom-0 left-0 -mb-12 -ml-12 w-32 h-32 bg-orange-200 rounded-full opacity-20"></div>
      </div>

      {/* Features Section */}
      <div className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Everything You Need to Succeed
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Our platform combines cutting-edge AI technology with intuitive design to create the perfect study environment
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div
                  key={index}
                  className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 cursor-pointer"
                  onClick={feature.action}
                >
                  <div className={`w-12 h-12 ${feature.bgColor} rounded-lg flex items-center justify-center mb-4`}>
                    <Icon className={`w-6 h-6 ${feature.iconColor}`} />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-gray-600 mb-4">
                    {feature.description}
                  </p>
                  <div className="flex items-center text-orange-500 font-medium">
                    <span>Explore</span>
                    <Zap className="w-4 h-4 ml-1" />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Statistics Section */}
      <div className="bg-orange-500 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-white mb-2">AI-Powered</div>
              <div className="text-orange-100">Intelligent Study Assistant</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-white mb-2">24/7</div>
              <div className="text-orange-100">Always Available Support</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-white mb-2">Smart</div>
              <div className="text-orange-100">Document Management</div>
            </div>
          </div>
        </div>
      </div>

      {/* Call to Action */}
      <div className="py-16 bg-white">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Ready to Transform Your Learning?
          </h2>
          <p className="text-lg text-gray-600 mb-8">
            Join thousands of students who are already studying smarter with 2ms
          </p>
          <button
            onClick={() => onNavigate('ai')}
            className="bg-orange-500 hover:bg-orange-600 text-white px-12 py-4 rounded-lg font-semibold text-xl transition-all duration-200 transform hover:scale-105 shadow-lg"
          >
            Get Started Now
          </button>
        </div>
      </div>
    </div>
  );
};

export default HomePage;