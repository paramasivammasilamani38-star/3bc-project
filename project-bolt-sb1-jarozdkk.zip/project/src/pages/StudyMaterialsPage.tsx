import React, { useState } from 'react';
import { BookOpen, Download, Search, Filter, Star, Clock, Tag, Users } from 'lucide-react';

interface StudyMaterial {
  id: string;
  title: string;
  subject: string;
  description: string;
  fileSize: string;
  downloadUrl: string;
  uploadDate: Date;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  tags: string[];
}

const StudyMaterialsPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('All');
  const [selectedDifficulty, setSelectedDifficulty] = useState('All');

  // Sample study materials - in production, this would come from a database
  const studyMaterials: StudyMaterial[] = [
    {
      id: '1',
      title: 'Introduction to Calculus',
      subject: 'Mathematics',
      description: 'Comprehensive guide covering limits, derivatives, and basic integration techniques.',
      fileSize: '2.4 MB',
      downloadUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
      uploadDate: new Date('2024-01-15'),
      difficulty: 'Beginner',
      tags: ['calculus', 'derivatives', 'limits', 'integration']
    },
    {
      id: '2',
      title: 'Organic Chemistry Fundamentals',
      subject: 'Chemistry',
      description: 'Essential concepts in organic chemistry including molecular structures and reactions.',
      fileSize: '3.1 MB',
      downloadUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
      uploadDate: new Date('2024-01-20'),
      difficulty: 'Intermediate',
      tags: ['organic', 'molecules', 'reactions', 'chemistry']
    },
    {
      id: '3',
      title: 'Physics: Mechanics and Motion',
      subject: 'Physics',
      description: 'Study guide covering Newton\'s laws, kinematics, and dynamics with solved examples.',
      fileSize: '1.8 MB',
      downloadUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
      uploadDate: new Date('2024-01-25'),
      difficulty: 'Beginner',
      tags: ['mechanics', 'newton', 'motion', 'physics']
    },
    {
      id: '4',
      title: 'Advanced Linear Algebra',
      subject: 'Mathematics',
      description: 'In-depth coverage of vector spaces, eigenvalues, and matrix transformations.',
      fileSize: '4.2 MB',
      downloadUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
      uploadDate: new Date('2024-02-01'),
      difficulty: 'Advanced',
      tags: ['linear algebra', 'vectors', 'matrices', 'eigenvalues']
    },
    {
      id: '5',
      title: 'Computer Science Algorithms',
      subject: 'Computer Science',
      description: 'Essential algorithms and data structures with complexity analysis and implementations.',
      fileSize: '3.7 MB',
      downloadUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
      uploadDate: new Date('2024-02-05'),
      difficulty: 'Intermediate',
      tags: ['algorithms', 'data structures', 'complexity', 'programming']
    },
    {
      id: '6',
      title: 'Biology: Cell Structure and Function',
      subject: 'Biology',
      description: 'Detailed study of cellular components, organelles, and biological processes.',
      fileSize: '2.9 MB',
      downloadUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
      uploadDate: new Date('2024-02-10'),
      difficulty: 'Beginner',
      tags: ['biology', 'cells', 'organelles', 'processes']
    }
  ];

  const subjects = ['All', ...Array.from(new Set(studyMaterials.map(material => material.subject)))];
  const difficulties = ['All', 'Beginner', 'Intermediate', 'Advanced'];

  const filteredMaterials = studyMaterials.filter(material => {
    const matchesSearch = material.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         material.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         material.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesSubject = selectedSubject === 'All' || material.subject === selectedSubject;
    const matchesDifficulty = selectedDifficulty === 'All' || material.difficulty === selectedDifficulty;
    
    return matchesSearch && matchesSubject && matchesDifficulty;
  });

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Beginner':
        return 'bg-green-100 text-green-800';
      case 'Intermediate':
        return 'bg-yellow-100 text-yellow-800';
      case 'Advanced':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getSubjectColor = (subject: string) => {
    const colors = {
      'Mathematics': 'bg-blue-100 text-blue-800',
      'Physics': 'bg-purple-100 text-purple-800',
      'Chemistry': 'bg-green-100 text-green-800',
      'Biology': 'bg-pink-100 text-pink-800',
      'Computer Science': 'bg-indigo-100 text-indigo-800',
    };
    return colors[subject as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  const handleDownload = (material: StudyMaterial) => {
    // In production, this would handle actual file downloads
    window.open(material.downloadUrl, '_blank');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b-2 border-orange-500">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="text-center mb-6">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Study Materials</h1>
            <p className="text-gray-600">Access high-quality PDF study materials across various subjects</p>
          </div>

          {/* Search and Filters */}
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Search materials, topics, or tags..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
            </div>

            <div className="flex gap-3">
              <select
                value={selectedSubject}
                onChange={(e) => setSelectedSubject(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
              >
                {subjects.map(subject => (
                  <option key={subject} value={subject}>{subject}</option>
                ))}
              </select>

              <select
                value={selectedDifficulty}
                onChange={(e) => setSelectedDifficulty(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
              >
                {difficulties.map(difficulty => (
                  <option key={difficulty} value={difficulty}>{difficulty}</option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Statistics */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <div className="flex items-center">
              <BookOpen className="w-8 h-8 text-orange-500 mr-3" />
              <div>
                <p className="text-2xl font-bold text-gray-900">{studyMaterials.length}</p>
                <p className="text-sm text-gray-600">Total Materials</p>
              </div>
            </div>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <div className="flex items-center">
              <Users className="w-8 h-8 text-blue-500 mr-3" />
              <div>
                <p className="text-2xl font-bold text-gray-900">{subjects.length - 1}</p>
                <p className="text-sm text-gray-600">Subjects</p>
              </div>
            </div>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <div className="flex items-center">
              <Star className="w-8 h-8 text-yellow-500 mr-3" />
              <div>
                <p className="text-2xl font-bold text-gray-900">4.8</p>
                <p className="text-sm text-gray-600">Avg Rating</p>
              </div>
            </div>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <div className="flex items-center">
              <Download className="w-8 h-8 text-green-500 mr-3" />
              <div>
                <p className="text-2xl font-bold text-gray-900">1.2k</p>
                <p className="text-sm text-gray-600">Downloads</p>
              </div>
            </div>
          </div>
        </div>

        {/* Materials Grid */}
        {filteredMaterials.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-lg shadow-sm">
            <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No materials found</h3>
            <p className="text-gray-500">Try adjusting your search terms or filters</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredMaterials.map((material) => (
              <div
                key={material.id}
                className="bg-white rounded-lg shadow-sm border hover:shadow-md transition-all duration-200 hover:-translate-y-1"
              >
                <div className="p-6">
                  {/* Header */}
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-gray-900 mb-2 line-clamp-2">
                        {material.title}
                      </h3>
                      <div className="flex items-center space-x-2 mb-2">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getSubjectColor(material.subject)}`}>
                          {material.subject}
                        </span>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(material.difficulty)}`}>
                          {material.difficulty}
                        </span>
                      </div>
                    </div>
                    <BookOpen className="w-8 h-8 text-orange-500 flex-shrink-0" />
                  </div>

                  {/* Description */}
                  <p className="text-gray-600 text-sm mb-4 line-clamp-3">
                    {material.description}
                  </p>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-1 mb-4">
                    {material.tags.slice(0, 3).map((tag, index) => (
                      <span
                        key={index}
                        className="inline-flex items-center px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded"
                      >
                        <Tag className="w-3 h-3 mr-1" />
                        {tag}
                      </span>
                    ))}
                    {material.tags.length > 3 && (
                      <span className="text-xs text-gray-500">+{material.tags.length - 3} more</span>
                    )}
                  </div>

                  {/* Footer */}
                  <div className="flex items-center justify-between pt-4 border-t">
                    <div className="flex items-center text-sm text-gray-500">
                      <Clock className="w-4 h-4 mr-1" />
                      {material.uploadDate.toLocaleDateString()}
                    </div>
                    <div className="flex items-center space-x-3">
                      <span className="text-sm text-gray-500">{material.fileSize}</span>
                      <button
                        onClick={() => handleDownload(material)}
                        className="bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200 flex items-center space-x-2"
                      >
                        <Download className="w-4 h-4" />
                        <span>Download</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Call to Action */}
        <div className="mt-12 bg-orange-500 rounded-lg p-8 text-center">
          <h2 className="text-2xl font-bold text-white mb-4">Need Help with Your Studies?</h2>
          <p className="text-orange-100 mb-6">
            Chat with Antony, our AI assistant, for personalized study guidance and explanations
          </p>
          <button className="bg-white text-orange-500 px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors duration-200">
            Chat with Antony
          </button>
        </div>
      </div>
    </div>
  );
};

export default StudyMaterialsPage;