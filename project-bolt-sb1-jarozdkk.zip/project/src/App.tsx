import React, { useState } from 'react';
import { AppProvider } from './context/AppContext';
import Navigation from './components/Navigation';
import HomePage from './pages/HomePage';
import AIAssistantPage from './pages/AIAssistantPage';
import StudyMaterialsPage from './pages/StudyMaterialsPage';
import PDFPage from './pages/PDFPage';
import CreditsPage from './pages/CreditsPage';

function App() {
  const [activeTab, setActiveTab] = useState('home');

  const renderContent = () => {
    switch (activeTab) {
      case 'home':
        return <HomePage onNavigate={setActiveTab} />;
      case 'ai':
        return <AIAssistantPage />;
      case 'materials':
        return <StudyMaterialsPage />;
      case 'pdf':
        return <PDFPage />;
      case 'credits':
        return <CreditsPage />;
      default:
        return <HomePage onNavigate={setActiveTab} />;
    }
  };

  return (
    <AppProvider>
      <div className="min-h-screen bg-gray-50">
        <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
        <main className="transition-all duration-300 ease-in-out">
          {renderContent()}
        </main>
      </div>
    </AppProvider>
  );
}

export default App;