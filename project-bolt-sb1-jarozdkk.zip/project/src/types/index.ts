export interface ChatMessage {
  id: string;
  content: string;
  sender: 'user' | 'antony';
  timestamp: Date;
}

export interface PDFDocument {
  id: string;
  name: string;
  size: number;
  uploadDate: Date;
  url: string;
}

export interface UserSession {
  id: string;
  createdAt: Date;
  lastActive: Date;
}

export interface StudyMaterial {
  id: string;
  title: string;
  subject: string;
  description: string;
  fileSize: string;
  downloadUrl: string;
  uploadDate: Date;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  tags: string[];
}