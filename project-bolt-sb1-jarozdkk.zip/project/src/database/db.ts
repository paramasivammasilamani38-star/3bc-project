import { ChatMessage, PDFDocument, UserSession } from '../types';

class DatabaseManager {
  private getStorageKey(key: string): string {
    return `2ms_${key}`;
  }

  private generateId(prefix: string): string {
    return `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  // Session management
  createSession(): UserSession {
    const sessionId = this.generateId('session');
    const session: UserSession = {
      id: sessionId,
      createdAt: new Date(),
      lastActive: new Date()
    };
    
    localStorage.setItem(this.getStorageKey('currentSession'), JSON.stringify(session));
    return session;
  }

  updateSessionActivity(sessionId: string): void {
    const sessionData = localStorage.getItem(this.getStorageKey('currentSession'));
    if (sessionData) {
      const session = JSON.parse(sessionData);
      if (session.id === sessionId) {
        session.lastActive = new Date();
        localStorage.setItem(this.getStorageKey('currentSession'), JSON.stringify(session));
      }
    }
  }

  // Chat message management
  saveChatMessage(sessionId: string, message: Omit<ChatMessage, 'id'>): ChatMessage {
    const messageId = this.generateId('msg');
    const chatMessage: ChatMessage = { ...message, id: messageId };
    
    const existingMessages = this.getChatHistory(sessionId);
    const updatedMessages = [...existingMessages, chatMessage];
    
    localStorage.setItem(
      this.getStorageKey(`chat_${sessionId}`), 
      JSON.stringify(updatedMessages)
    );
    
    return chatMessage;
  }

  getChatHistory(sessionId: string): ChatMessage[] {
    const messagesData = localStorage.getItem(this.getStorageKey(`chat_${sessionId}`));
    if (!messagesData) return [];
    
    const messages = JSON.parse(messagesData);
    return messages.map((msg: any) => ({
      ...msg,
      timestamp: new Date(msg.timestamp)
    }));
  }

  // PDF document management
  savePDFDocument(sessionId: string, document: Omit<PDFDocument, 'id'>): PDFDocument {
    const docId = this.generateId('pdf');
    const pdfDocument: PDFDocument = { ...document, id: docId };
    
    const existingDocs = this.getPDFDocuments(sessionId);
    const updatedDocs = [pdfDocument, ...existingDocs];
    
    localStorage.setItem(
      this.getStorageKey(`pdfs_${sessionId}`), 
      JSON.stringify(updatedDocs)
    );
    
    return pdfDocument;
  }

  getPDFDocuments(sessionId: string): PDFDocument[] {
    const docsData = localStorage.getItem(this.getStorageKey(`pdfs_${sessionId}`));
    if (!docsData) return [];
    
    const docs = JSON.parse(docsData);
    return docs.map((doc: any) => ({
      ...doc,
      uploadDate: new Date(doc.uploadDate)
    }));
  }

  deletePDFDocument(documentId: string): void {
    // Get current session to find the right storage key
    const sessionData = localStorage.getItem(this.getStorageKey('currentSession'));
    if (!sessionData) return;
    
    const session = JSON.parse(sessionData);
    const existingDocs = this.getPDFDocuments(session.id);
    const updatedDocs = existingDocs.filter(doc => doc.id !== documentId);
    
    localStorage.setItem(
      this.getStorageKey(`pdfs_${session.id}`), 
      JSON.stringify(updatedDocs)
    );
  }

  close(): void {
    // No-op for localStorage implementation
  }
}

export default new DatabaseManager();